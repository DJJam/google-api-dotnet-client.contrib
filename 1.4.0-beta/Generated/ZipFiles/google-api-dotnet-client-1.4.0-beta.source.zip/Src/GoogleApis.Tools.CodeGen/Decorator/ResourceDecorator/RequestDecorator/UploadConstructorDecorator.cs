﻿/*
Copyright 2012 Google Inc

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

using Google.Apis.Discovery;
using Google.Apis.Services;
using Google.Apis.Testing;
using Google.Apis.Tools.CodeGen.Generator;

namespace Google.Apis.Tools.CodeGen.Decorator.ResourceDecorator.RequestDecorator
{
    /// <summary>
    /// Generates the standard constructors of an upload request.
    /// A resumable upload constructor takes the service and mandatory parameters and initializes the base class with 
    /// the service, path and HTTP method for this upload request.
    /// Example:
    /// <c>
    /// public InsertRequest(IClientService service, int requiredParameter, ..) 
    ///     : base(service, "path", "POST") {..}
    /// </c>
    /// </summary>
    public class UploadConstructorDecorator : BaseRequestConstructorDecorator
    {
        private const string ServiceName = "service";
        private const string BasePathName = "BasePath";

        private const string StreamParameterName = "stream";
        private const string ContentTypeParameterName = "contentType";

        /// <summary>
        /// Creates a new request constructor decorator.
        /// </summary>
        /// <remarks>Will create the constructor with all required properties.</remarks>
        public UploadConstructorDecorator(IObjectTypeProvider objectTypeProvider) : base(objectTypeProvider) { }

        #region IRequestDecorator Members

        public override void DecorateClass(IResource resource,
                                  IMethod request,
                                  CodeTypeDeclaration requestClass,
                                  CodeTypeDeclaration resourceClass)
        {
            requestClass.Members.Add(CreateRequiredConstructor(resourceClass, request, false));
        }

        #endregion

        /// <summary>
        /// Creates the constructor for this request class which only takes required arguments.
        /// </summary>
        [VisibleForTestOnly]
        internal CodeConstructor CreateRequiredConstructor(CodeTypeDeclaration resourceClass,
                                                           IMethod request,
                                                           bool addOptionalParameters)
        {
            var constructor = new CodeConstructor();
            constructor.Attributes = MemberAttributes.Public;

            // IClientService service
            var serviceArg = new CodeParameterDeclarationExpression(typeof(IClientService), ServiceName);
            constructor.Parameters.Add(serviceArg);

            // : base(service, string.Format("/{0}{1}{2}", "upload", service.BasePath, "RESOURCE_PATH"), 
            // "HTTP_METHOD", ... (required parameters)

            // service
            constructor.BaseConstructorArgs.Add(
                new CodeVariableReferenceExpression(ServiceName));

            // string.Format("/{0}{1}{2}", "upload", service.BasePath, "RESOURCE_PATH")
            var path = new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(
                new CodeTypeReferenceExpression(typeof(string)), "Format"),
                    new CodePrimitiveExpression("/{0}{1}{2}"),
                    new CodePrimitiveExpression("upload"),
                    new CodePropertyReferenceExpression(
                        new CodeVariableReferenceExpression(ServiceName), BasePathName),
                    new CodePrimitiveExpression(request.RestPath));
            constructor.BaseConstructorArgs.Add(path);
            // "HTTP_METHOD"
            constructor.BaseConstructorArgs.Add(new CodePrimitiveExpression(request.HttpMethod));

            // Add all required arguments to the constructor.
            AddBodyParameter(constructor, request);

            // Add common upload arguements.
            constructor.BaseConstructorArgs.Add(new CodeVariableReferenceExpression(StreamParameterName));
            constructor.BaseConstructorArgs.Add(new CodeVariableReferenceExpression(ContentTypeParameterName));

            AddRequestParameters(resourceClass, request, constructor, addOptionalParameters);

            constructor.Parameters.Add(new CodeParameterDeclarationExpression(
                new CodeTypeReference(typeof(System.IO.Stream)), StreamParameterName));
            constructor.Parameters.Add(new CodeParameterDeclarationExpression(
                new CodeTypeReference(typeof(System.String)), ContentTypeParameterName));

            return constructor;
        }
    }
}